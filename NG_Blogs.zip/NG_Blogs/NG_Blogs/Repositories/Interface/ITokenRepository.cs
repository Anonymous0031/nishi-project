﻿using Microsoft.AspNetCore.Identity;

namespace NG_Blogs.API.Repositories.Interface
{
    public interface ITokenRepository
    {
        string CreateJwtToken(IdentityUser user, List<string> roles);
    }
}
